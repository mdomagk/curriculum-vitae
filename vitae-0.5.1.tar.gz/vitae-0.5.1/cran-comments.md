This submission resolves issues in the CRAN check results.

## Test environments
* local kubuntu 20.04 install, R 4.0.2
* ubuntu 16.04 (on GitHub actions), R-devel, R 4.0.0, R 3.6.3, R 3.5.3
* macOS (on GitHub actions), R 4.0.0
* windows (on GitHub actions), R 4.0.0
* win-builder, R-devel, R-release, R-oldrelease

## R CMD check results

0 errors | 0 warnings | 0 notes
