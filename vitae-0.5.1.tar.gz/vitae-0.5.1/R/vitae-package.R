#' @keywords internal
"_PACKAGE"

#' @import rlang
#' @import vctrs
NULL
