library(testthat)
library(vitae)

test_check("vitae")
